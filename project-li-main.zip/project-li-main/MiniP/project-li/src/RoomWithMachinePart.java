// RoomWithMachinePart class
public class RoomWithMachinePart extends Room {
    private Part machinePart;

    public RoomWithMachinePart(int number, Part machinePart) {
        super(number);
        this.machinePart = machinePart;
    }

    @Override
    public boolean hasPart() {
        return true;
    }

    public Part collectPart(Player player) {
        if (player.getLastMachinePartCollected() == null || machinePart.isNext(player.getLastMachinePartCollected())) {
            player.setLastMachinePartCollected(machinePart);
            return machinePart;
        } else {
            return null;
        }
    }

    @Override
    public String helpMessage() {
        return "You are in Room " + getNumber() + ". Part " + machinePart.getNumber() + " is here.";
    }
}