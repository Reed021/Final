
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
 
public class Maze extends Application {
    private Game game;

    public static void main(String[] args) {
        launch(args);
    }
    
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Maze Game");
        game = new Game(null);

        //Text Boxes
        TextField p1Box = new TextField();
        TextField p2Box = new TextField();
        p1Box.setPrefWidth(280);
        p2Box.setPrefWidth(280);
        p1Box.setEditable(false);
        p2Box.setEditable(false);
       
       
        //TextBoxes:
        AnchorPane.setTopAnchor(p1Box, 218.0);
        AnchorPane.setLeftAnchor(p1Box, 20.0);
        AnchorPane.setTopAnchor(p2Box, 218.0);
        AnchorPane.setLeftAnchor(p2Box, 510.0);
        root.getChildren().addAll(p1Box, p2Box);
        
        
        // Player 1 Layout: ................

        //Up Button P1
        Button UbtnP1 = new Button("Up");
        UbtnP1.setOnAction(new EventHandler<ActionEvent>() {
 
            @Override
            public void handle(ActionEvent event) {
                game.movePlayer(Direction.up);
                updateMessage(message, p1Box);
            }
        });

        //Right Button P1
        Button RbtnP1 = new Button("Right");
        RbtnP1.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                game.movePlayer(Direction.right);
            }
        });

        //Down Button P1
        Button DbtnP1 = new Button("Down");
        DbtnP1.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                game.movePlayer(Direction.down);
            }
        });

        //Left Button P1
        Button LbtnP1 = new Button("Left");
        LbtnP1.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                game.movePlayer(Direction.left);
            }
        });


        //P1 Operational Buttons
        Button CPbtnP1 = new Button("Collect Part");
        CPbtnP1.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                game.collectPart();
            }
        });

        Button CTbtnP1 = new Button("Collect Tools");
        CTbtnP1.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                game.collectTools();
            }
        });

        Button BMbtnP1 = new Button("Build Machines");
        BMbtnP1.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                game.buildMachine();
            }
        });

        Button HbtnP1 = new Button("Help! I am Lost!");
        HbtnP1.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                updateMessage(game.getCurrentPlayer().getCurrentRoom().helpMessage());
            }
        });

        // Player 2 Layout: ................

        //Up Button P2
        Button UbtnP2 = new Button("Up");
        UbtnP2.setOnAction(new EventHandler<ActionEvent>() {
 
            @Override
            public void handle(ActionEvent event) {
                game.movePlayer(Direction.up);
            }
        });

        // Right Button Player 2
        Button RbtnP2 = new Button("Right");
        RbtnP2.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                game.movePlayer(Direction.right);
            }
        });

        // Down Button Player 2
        Button DbtnP2 = new Button("Down");
        DbtnP2.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                game.movePlayer(Direction.down);
            }
        });

        // Left Button Player 2
        Button LbtnP2 = new Button("Left");
        LbtnP2.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                game.movePlayer(Direction.left);
            }
        });

        //Player 2 Operation Buttons

        Button CPbtnP2 = new Button("Collect Part");
        CPbtnP2.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                game.collectPart();
            }
        });

        Button CTbtnP2 = new Button("Collect Tools");
        CTbtnP2.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                game.collectTools();
            }
        });

        Button BMbtnP2 = new Button("Build Machines");
        BMbtnP2.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                game.buildMachine();
            }
        });

        Button HbtnP2 = new Button("Help! I am Lost!");
        HbtnP2.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                updateMessage(game.getCurrentPlayer().getCurrentRoom().helpMessage());
            }
        });

        //Reset Button
        Button RSTbtn = new Button("Restart");
        RSTbtn.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                game.resetGame();
                String message = game.restart()
                updateMessage(message, p1Box);
                updateMessage(message, p2Box);
            }
        });


        //Labels
        Label p1 = new Label("Player 1");
        Label p2 = new Label("Player 2");
        AnchorPane root = new AnchorPane();
        

        //Labels: 
            //Player 1 Label
        AnchorPane.setTopAnchor(p1, 20.0);
        AnchorPane.setLeftAnchor(p1, 124.0);
            //Player 2 Label
        AnchorPane.setTopAnchor(p2, 20.0);
        AnchorPane.setLeftAnchor(p2, 615.0);

        // P1 Buttons
        AnchorPane.setTopAnchor(UbtnP1, 50.0); //UpbtnP1 Top anchor
        AnchorPane.setLeftAnchor(UbtnP1, 128.0); //UpbtnP1 Left anchor

        AnchorPane.setTopAnchor(RbtnP1, 100.0); //RbtnP1 Top anchor
        AnchorPane.setLeftAnchor(RbtnP1, 175.0); //RbtnP1 Left anchor

        AnchorPane.setTopAnchor(DbtnP1, 150.0); //DbtnP1 Top anchor
        AnchorPane.setLeftAnchor(DbtnP1, 121.0); //DbtnP1 Left anchor

        AnchorPane.setTopAnchor(LbtnP1, 100.0); //LbtnP1 Top anchor
        AnchorPane.setLeftAnchor(LbtnP1, 75.0); //LbtnP1 Left anchor
        root.getChildren().addAll(UbtnP1, RbtnP1, DbtnP1, LbtnP1, p1);

        // P2 Buttons
        AnchorPane.setTopAnchor(UbtnP2, 50.0); // UpbtnP2 Top anchor
        AnchorPane.setLeftAnchor(UbtnP2, 620.0); // UpbtnP2 Left anchor

        AnchorPane.setTopAnchor(RbtnP2, 100.0); // RbtnP2 Top anchor
        AnchorPane.setLeftAnchor(RbtnP2, 565.0); // RbtnP2 Left anchor

        AnchorPane.setTopAnchor(DbtnP2, 150.0); // DbtnP2 Top anchor
        AnchorPane.setLeftAnchor(DbtnP2, 615.0); // DbtnP2 Left anchor

        AnchorPane.setTopAnchor(LbtnP2, 100.0); // LbtnP2 Top anchor
        AnchorPane.setLeftAnchor(LbtnP2, 670.0); // LbtnP2 Left anchor
        root.getChildren().addAll(UbtnP2, RbtnP2, DbtnP2, LbtnP2, p2);

        //Misc Buttons

        //P1 side
        AnchorPane.setTopAnchor(CPbtnP1, 180.0); // CPbtnP1 Top anchor
        AnchorPane.setLeftAnchor(CPbtnP1, 20.0); // CPbtnP1 Left anchor

        AnchorPane.setTopAnchor(CTbtnP1, 180.0); // CTbtnP1 Top anchor
        AnchorPane.setLeftAnchor(CTbtnP1, 105.0); // CTbtnP1 Left anchor

        AnchorPane.setTopAnchor(BMbtnP1, 180.0); // BMbtnP1 Top anchor
        AnchorPane.setLeftAnchor(BMbtnP1, 195.0); // BMbtnP1 Left anchor

        AnchorPane.setTopAnchor(HbtnP1, 250.0); // Hbtn Top anchor
        AnchorPane.setLeftAnchor(HbtnP1, 100.0); // Hbtn Left anchor

        root.getChildren().addAll(CPbtnP1, CTbtnP1, BMbtnP1, HbtnP1);

        //P2 side
        AnchorPane.setTopAnchor(CPbtnP2, 180.0); // CPbtnP2 Top anchor
        AnchorPane.setLeftAnchor(CPbtnP2, 510.0); // CPbtnP2 Left anchor

        AnchorPane.setTopAnchor(CTbtnP2, 180.0); // CTbtnP2 Top anchor
        AnchorPane.setLeftAnchor(CTbtnP2, 595.0); // CTbtnP2 Left anchor

        AnchorPane.setTopAnchor(BMbtnP2, 180.0); // BMbtnP2 Top anchor
        AnchorPane.setLeftAnchor(BMbtnP2, 687.0); // BMbtnP2 Left anchor

        AnchorPane.setTopAnchor(HbtnP2, 250.0); // Hbtn Top anchor
        AnchorPane.setLeftAnchor(HbtnP2, 590.0); // Hbtn Left anchor
        root.getChildren().addAll(CPbtnP2, CTbtnP2, BMbtnP2, HbtnP2);

        //General Buttons 
        AnchorPane.setTopAnchor(RSTbtn, 300.0); // RSTbtn Top anchor
        AnchorPane.setLeftAnchor(RSTbtn, 380.0); // RSTbtn Left anchor
        
        String message = "";


    root.getChildren().addAll(RSTbtn);


    Scene scene = new Scene(root, 800, 400);
    primaryStage.setScene(scene);
    primaryStage.show();

    }
}