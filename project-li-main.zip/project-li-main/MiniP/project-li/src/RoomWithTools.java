public class RoomWithTools extends Room {
    public RoomWithTools(int number) {
        super(number);
    }

    @Override
    public boolean hasTools() {
        return true;
    }

    @Override
    public String helpMessage() {
        return "You are in Room " + getNumber() + ". Tools are here.";
    }
}