public class Part {
    private int number;
    private static final int LAST_PART = 5; // Assuming there are 5 parts in total

    public Part(int number) {
        this.number = number;
    }

    public int getNumber() {
        return number;
    }

    public boolean isLastPart() {
        return number == LAST_PART;
    }

    public boolean isNext(Part otherPart) {
        return otherPart.getNumber() == number - 1;
    }
}
