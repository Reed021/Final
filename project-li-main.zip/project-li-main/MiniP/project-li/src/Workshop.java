public class Workshop extends Room {
    public Workshop(int number) {
        super(number);
    }

    @Override
    public boolean isWorkshop() {
        return true;
    }

    @Override
    public String helpMessage() {
        return "You are in the Workshop (Room " + getNumber() + ").";
    }
}