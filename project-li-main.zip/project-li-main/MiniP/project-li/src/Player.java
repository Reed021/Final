public class Player {
    private int number;
    private Room currentRoom;
    private boolean toolsCollected;
    private Part lastMachinePartCollected;

    public Player(int number, Room currentRoom) {
        this.number = number;
        this.currentRoom = currentRoom;
    }

    public Room getCurrentRoom() {
        return currentRoom;
    }
    public boolean hasTools() {
        return toolsCollected;
    }

    public Part getLastMachinePartCollected() {
        return lastMachinePartCollected;
    }

    public int getNumber() {
        return number;
    }

    public void setLastMachinePartCollected(Part lastMachinePartCollected) {
        this.lastMachinePartCollected = lastMachinePartCollected;
    }

    public String move(int direction) {
        Room nextRoom = currentRoom.getDoor(direction);
        if (nextRoom != null) {
            currentRoom = nextRoom;
            return currentRoom.printMessage();
        } else {
            return "No door in this direction";
        }
    }

    public String collectPart() {
        if (!(currentRoom instanceof RoomWithMachinePart)) {
            return "Room does not have machine parts";
        }

        RoomWithMachinePart roomWithPart = (RoomWithMachinePart) currentRoom;
        Part part = roomWithPart.collectPart(this);

        if (part == null) {
            return "Parts must be collected in order";
        } else {
            return "You have successfully collected part " + part.getNumber();
        }
    }

    public String collectTools() {
        if (!(currentRoom instanceof RoomWithTools)) {
            return "Room does not have tools";
        }

        if (toolsCollected) {
            return "Tools already collected";
        } else {
            toolsCollected = true;
            return "You have successfully collected tools";
        }
    }

    public String build() {
        if (!(currentRoom instanceof Workshop)) {
            return "You are not in the workshop";
        }

        if (!toolsCollected) {
            return "You don't have the tools";
        }

        if (lastMachinePartCollected == null || !lastMachinePartCollected.isLastPart()) {
            return "You don't have all the parts";
        }

        return "Task Completed! You Win!!!!";
    }
}
