/**
 * This class holds the whole game and its components (the two players and 10 rooms). 
 * This class should be instantiated in the main application class 
 * @author ADD YOUR NAME
 */

 import javafx.scene.control.TextField;

public class Game {
	private Player[] players;
	private Room[] rooms;
	private Player currentPlayer;
    private TextField messageField; //TextField to display messages in GUI

    
	public Game(TextField messageField) {
        this.messageField = messageField;
        // Initialize players array
        players = new Player[2];
        // Initialize rooms array
        rooms = new Room[10];

        // Create rooms based on their types on the map
        for (int i = 0; i < 10; i++) {
            if (i == 2 || i == 5) {
                rooms[i] = new RoomWithTools(i + 1); // Room with tools
            } else if (i == 9) {
                rooms[i] = new Workshop(i + 1); // Workshop
            } else {
                rooms[i] = new Room(i + 1); // Generic room
            }
        }

        // Set up doors between rooms
        try {
            setUpDoors();
        } catch (Exception e) {
            e.printStackTrace();
        }

		initGame();
    }


	   /**
	    * Assuming that Rooms has been initialized in the constructor 
	    * to hold 10 objects of type Room or a subclass of Room, this method 
	    * sets up the doors between the rooms, as described in the map
	    * @return void
	    * @throws Exception if inconsistencies found by setDoor
	    */
	
	private void setUpDoors() throws Exception {
		rooms[0].setDoor(Direction.up, rooms[3]);
		rooms[0].setDoor(Direction.left, rooms[8]);
		
		rooms[1].setDoor(Direction.up, rooms[4]);
		rooms[1].setDoor(Direction.down, rooms[7]);
		rooms[1].setDoor(Direction.right, rooms[9]);

		rooms[2].setDoor(Direction.down, rooms[8]);

		rooms[3].setDoor(Direction.down, rooms[0]);
		rooms[3].setDoor(Direction.right, rooms[4]);

		rooms[4].setDoor(Direction.down, rooms[1]);
		rooms[4].setDoor(Direction.right, rooms[5]);
		rooms[4].setDoor(Direction.left, rooms[3]);

		rooms[5].setDoor(Direction.down, rooms[9]);
		rooms[5].setDoor(Direction.left, rooms[4]);

		rooms[6].setDoor(Direction.up, rooms[8]);
		rooms[6].setDoor(Direction.right, rooms[7]);

		rooms[7].setDoor(Direction.up, rooms[1]);
		rooms[7].setDoor(Direction.left, rooms[6]);

		rooms[8].setDoor(Direction.up, rooms[2]);
		rooms[8].setDoor(Direction.down, rooms[6]);
		rooms[8].setDoor(Direction.right, rooms[0]);

		rooms[9].setDoor(Direction.up, rooms[5]);
		rooms[9].setDoor(Direction.left, rooms[1]);

	}	

	private void initGame() {
        players[0] = new Player(1, rooms[0]); // Player 1 starts in Room 1
        players[1] = new Player(2, rooms[0]); // Player 2 also starts in Room 1
        currentPlayer = players[0]; // Player 1 starts first
    }

    // Getter method for the current player
    public Player getCurrentPlayer() {
        return currentPlayer;
    }

    // Method to switch players
    public void switchPlayer() {
        if (currentPlayer == players[0]) {
            currentPlayer = players[1];
        } else {
            currentPlayer = players[0];
        }
    }

    // Method to start the game
    public void startGame() {
        // Your game logic to start the game  // NEEDS EDITING
    }

    public void movePlayer(int direction) {
        String message = currentPlayer.move(direction);
        updateMessage(message);
        processPlayerTurn();
    }

    public void collectPart() {
        String message = currentPlayer.collectPart();
        updateMessage(message);
        processPlayerTurn();
    }
    public void collectTools() {
        String message = currentPlayer.collectTools();
        updateMessage(message);
        processPlayerTurn();
    }
    public void buildMachine() {
        String message = currentPlayer.build();
        updateMessage(message);
        processPlayerTurn();
    }
    public void askForHelp() {
        String message = currentPlayer.getCurrentRoom().helpMessage();
        updateMessage(message);
    }
    public void resetGame() {
        initGame();
        updateMessage("Game Reset. Players have been returned to Room 1");
    }
    private void processPlayerTurn() {
        switchPlayer();
        updateMessage("Player" + currentPlayer.getNumber() + "'s turn.")
    }
    private void updateMessage(String message) {
        messageField.setText(message);
    }
} 

