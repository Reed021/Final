/**
	* WritingCourse class extends Course representing a writing intensive course.
	*/
    public class WritingCourse extends Course {
        /**
        * Constructor for WritingCourse.
        * @param courseCode The code of the course.
        * @param courseName The name of the course.
        * @param courseSubject The subject of the course.
        * @param courseCredits The credit hours of the course.
        */
            public WritingCourse(String courseCode, String courseName, String courseSubject, int courseCredits) {
            super(courseCode, courseName, courseSubject, courseCredits);
            }
        @Override
        public void displayInfo() {
            super.displayInfo();
            System.out.println("This course is a writing course and will satisfy W-course requirements.");
        }
    }   