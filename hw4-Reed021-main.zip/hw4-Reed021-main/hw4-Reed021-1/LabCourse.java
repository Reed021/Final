/**
	* LabCourse class extends Course and represents a course with a lab component.
	*/
    public class LabCourse extends Course {
        /**
        * Constructor for LabCourse.
        * @param courseCode The code of the course.
        * @param courseName The name of the course.
        * @param courseSubject The subject of the course.
        * @param courseCredits The credit hours of the course.
        */
        public LabCourse(String courseCode, String courseName, String courseSubject, int courseCredits) {
        super(courseCode, courseName, courseSubject, courseCredits);
        }
        /**
        * Overrides displayInfo method to add information about the lab component.
        */
        @Override
        public void displayInfo() {
        super.displayInfo();
        System.out.println("This course has a lab component and additional fees may apply.");
        }
    }
