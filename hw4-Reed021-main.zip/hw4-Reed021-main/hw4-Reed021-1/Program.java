/**
 * Program class manages courses, adding them and displaying their information.
 */
import java.util.Arrays;
public class Program {
 
	/** Array to store the courses. */
	public Course[] courses; 
	/**
	* Constructor to initialize the Program object with the given number of courses.
	* @param numCourses The number of courses to initialize.
	*/
	public Program(int numCourses) {
	courses = new Course[numCourses]; 
	}
	/**
	* Main method to demonstrate the functionality of the Program class.
	* @param args Command-line arguments (not used).
	*/
	public static void main(String[] args) {
	String[][] courseInfo = { 
	{ "CHE", "120", "General Chemistry I", "Chemistry", "4" },
	{ "CHE", "121", "General Chemistry II", "Chemistry", "4" },
	{ "CSC", "207", "Computer Systems", "Computer Science", "4" },
	{ "CSC", "229", "Object-Oriented Programming", "Computer Science", "3" },
	{ "CSC", "324W", "Computer Ethics", "Computer Science", "3" },
	{ "CSC", "330", "Software Design and Development", "Computer Science", "3" },
	{ "ENG", "112", "Writing Arguments", "English", "3" },
	{ "ENG", "217W", "Introduction to Literature", "English", "3" },
	{ "MAT", "125", "Applied Business Mathematics", "Mathematics", "3" },
	{ "MAT", "150", "Calculus I", "Mathematics", "4" },
	{ "MAT", "151", "Calculus II", "Mathematics", "4" },
	{ "MAT", "221", "Intermediate Applied Statistics", "Mathematics", "4" },
	{ "PHY", "230", "Physics for Scientists and Engineers I", "Physics", "4" },
	{ "PHY", "231", "Physics for Scientists and Engineers II", "Physics", "4" }
	};
	
	Program courseMngmt = new Program(courseInfo.length);
	
	courseMngmt.addCourses(courseInfo);
	Arrays.sort(courseMngmt.courses); //Sorting the array
	courseMngmt.displayCourses();
	}
	
	/**
	* Adds courses based on the information provided in the courseInfo array.
	* @param courseInfo Array containing course information.
	*/
	public void addCourses(String[][] courseInfo) {
		for (int i = 0; i < courseInfo.length; i++ ) {
			String courseName = courseInfo[i][2];
			int courseCredits = Integer.parseInt(courseInfo[i][4]);
			String courseCode = courseInfo[i][0] + "-" + courseInfo[i][1];
			String courseSubject = courseInfo[i][3];
			
			if (courseCode.endsWith("W")) {
			courses[i] = new WritingCourse(courseCode, courseName, courseSubject, courseCredits);
			} else if (courseCredits == 4) {
			courses[i] = new LabCourse(courseCode, courseName, courseSubject, courseCredits);
			} else {
			courses[i] = new Course(courseCode, courseName, courseSubject, courseCredits);
			}
		}
	}

	/**
	* Displays information for all courses stored in the courses array.
	*/
	public void sortCourses(){
		Arrays.sort(courses);
	}

	public void displayCourses() {
		for (int i = 0; i < courses.length; i++) {
			courses[i].displayInfo();
			System.out.println(); // adds an empty line after every course
		}
	}
}